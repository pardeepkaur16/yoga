import java.util.*;
class OnlineYoga{
int id;
double cost;
String name;
public Onlineyoga(){
System.out.println("Online Yoga Payment System");
}
public Onlineyoga(int i, string n, double c)
{//constructor of class
this.id=i;
this.name=n;
this.cost=c;
}
public void setName(string n){
this.name=n;
}
public void setCost(double c){
if(c<=0){
System.out.println("Practice Cost should be non-zero value");}
else
this.cost=c;
}
public void setId(int n){//getter and setter methods
this.id=n;}
public double getCost(){
return this.cost;}
public int getId(){
return this.id;}
public string getName(){
return this.name;}
public void print(){
System.out.println("Online Yoga Details=");
System.out.println("Online Yoga Id is "+this.id);
System.out.println("Practice name is "+this.name);//print details
System.out.println("Practice cost is "+this.cost);
System.out.println();
}
public void print(String type){
double c;
c=this.cost;
if(type.equals("SPECIAL"))
c=c+30;
else id(type.equals("STANDARD"))//check type and compute cost
c=c+10;
setCost(c);
System.out.println("Online Yoga Details with Type");
System.out.println("Online Yoga Id is" +this.id);//print details
System.out.println("Practice name is "+this.name);
System.out.println("Practice type is "+this.type);
System.out.println("Practice cost is "+this.cost);
System.out.println("Discount is "+this.discount());
System.out.println;
}
public double discount(){
d=this.cost*0.2;//compute and return discount
return d;

}
}
public class OnlineyogaTest
{
public static void main(String[] args){
int id,ch;
double cost;
string name,type;
Scanner inp=new Scanner(System.in);
System.out.println("Online Yoga Payment System")
System.out.println("Input Zoom Id:");
id=inp.nextInt();
System.out.print("Input Practice Name:");//read inputs from user
name=inp.nextLine();
name=inp.nextLine();
System.out.println("Input Practice Cost:");
cost=inp.nextDouble();
System.out.print("Input Practice Type:");
name=inp.nextLine();
name=inp.nextLine();
Onlineyoga o=new Onlineyoga(id,name,cost);
while(true){
System.out.println("Online Yoga Payment Menu:");//print menu
System.out.println("[1]Online Yoga practices");
System.out.println("[2]Online yoga practices with types");
System.out.println("[3]Quit");
System.out.println("Enter the choice:");
ch=inp.nextInt();//read choice
if(ch==1)
o.print();
else if(ch==2)//call function based on choice
o.print(type);
else if(ch==3)
break;
}

}}



